from setuptools import setup

setup(name='fixer-demo',
      version='0.1',
      description='fixer service demo package',
      url='#',
      outher='Nima',
      outher_email='nima.abbasnejad14@gmail.com',
      license='MIT',
      packages=['fixer'],
      zip_safe=False)
