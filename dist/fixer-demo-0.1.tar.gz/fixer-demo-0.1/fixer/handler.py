def get_rate():
    print("Getrate Touched")
